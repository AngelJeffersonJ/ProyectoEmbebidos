﻿"""Central place to instantiate Flask extensions."""
from flask_cors import CORS

cors = CORS()
