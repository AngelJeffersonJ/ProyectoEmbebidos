﻿"""Route blueprints for wardrive-system."""
